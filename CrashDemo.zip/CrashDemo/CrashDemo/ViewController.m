//
//  ViewController.m
//  CrashDemo
//
//  Created by HLH on 16/4/26.
//  Copyright © 2016年 HLH. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    //这里打开就可以看到控制台输出异常信息
//    [dict setObject:nil forKey:@"kong"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
