//
//  UncaughtExceptionHandler.h
//  ZhuRenWong
//
//  Created by HLH on 15/11/14.
//  Copyright © 2015年 qitian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//@interface UncaughtExceptionHandler : NSObject
//
//@end
@interface UncaughtExceptionHandler1:UIViewController{
    BOOL dismissed;
    
}

@end

void HandleException(NSException *exception);
void SignalHandler(int signal);


void InstallUncaughtExceptionHandler(void);


