//
//  UncaughtExceptionHandler.m
//  ZhuRenWong
//
//  Created by HLH on 15/11/14.
//  Copyright © 2015年 qitian. All rights reserved.
//

#import "UncaughtExceptionHandler1.h"
#import <UIKit/UIKit.h>
//@implementation UncaughtExceptionHandler
//
//@end
#import "UncaughtExceptionHandler1.h"
#include <libkern/OSAtomic.h>
#include <execinfo.h>
#import <MessageUI/MFMessageComposeViewController.h>

//http://www.cocoachina.com/newbie/tutorial/2012/0829/4672.html
NSString * const UncaughtExceptionHandlerSignalExceptionName1 = @"UncaughtExceptionHandlerSignalExceptionName1";
NSString * const UncaughtExceptionHandlerSignalKey1 = @"UncaughtExceptionHandlerSignalKey1";
NSString * const UncaughtExceptionHandlerAddressesKey1 = @"UncaughtExceptionHandlerAddressesKey1";

volatile int32_t UncaughtExceptionCount1 = 0;
const int32_t UncaughtExceptionMaximum1 = 10;

const NSInteger UncaughtExceptionHandlerSkipAddressCount1 = 4;
const NSInteger UncaughtExceptionHandlerReportAddressCount1 = 5;
@interface UncaughtExceptionHandler1()<MFMessageComposeViewControllerDelegate>
@property(nonatomic,copy) NSString*msg;
@end

@implementation UncaughtExceptionHandler1

+ (NSArray *)backtrace
{
    void* callstack[128];
    int frames = backtrace(callstack, 128);
    char **strs = backtrace_symbols(callstack, frames);
    
    int i;
    NSMutableArray *backtrace = [NSMutableArray arrayWithCapacity:frames];
    for (
         i = UncaughtExceptionHandlerSkipAddressCount1;
         i < UncaughtExceptionHandlerSkipAddressCount1 +
         UncaughtExceptionHandlerReportAddressCount1;
         i++)
    {
        [backtrace addObject:[NSString stringWithUTF8String:strs[i]]];
    }
    free(strs);
    
    return backtrace;
}

- (void)alertView:(UIAlertView *)anAlertView clickedButtonAtIndex:(NSInteger)anIndex
{
    if (anIndex == 0)
    {
        dismissed = YES;
    }else if (anIndex==1) {
    }else if (anIndex==2){
    }
}



//保存关键的数据
- (void)validateAndSaveCriticalApplicationData
{
    
    
}


-(void)showMessageViewController:(NSString*)msg
{
    if( [MFMessageComposeViewController canSendText] )//判断是否能发短息
    {
        
        MFMessageComposeViewController * controller = [[MFMessageComposeViewController alloc]init];
        controller.recipients = [NSArray arrayWithObject:@"18271856994"];//接收人,可以有很多,放入数组
        controller.body = msg;//短信内容,自定义即可
        controller.messageComposeDelegate = self;//注意不是delegate
        
        [self presentViewController:controller animated:YES completion:nil];
        
        [[[[controller viewControllers] lastObject] navigationItem] setTitle:@"发送短信"];//修改短信界面标题
    }
    else
    {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"抱歉" message:@"短信功能不可用!" delegate:self cancelButtonTitle:@"好" otherButtonTitles:nil];
        [alert show];
    }
}

//短信发送成功后的回调
-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [controller dismissViewControllerAnimated:YES completion:nil];
    UIAlertView *mfAlertview;
    switch (result)
    {
        case MessageComposeResultCancelled:
        {
            //用户取消发送
        }
            break;
        case MessageComposeResultFailed://发送短信失败
        {
            mfAlertview=[[UIAlertView alloc]initWithTitle:@"抱歉" message:@"短信发送失败" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil];
            
            [mfAlertview show];
            
        }
            break;
        case MessageComposeResultSent:
        {
            mfAlertview= [[UIAlertView alloc]initWithTitle:@"非常感谢您" message:@"短信发送成功!" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil];
            
            [mfAlertview show];
            
        }
            break;
        default:
            break;
    }
}


- (void)handleException1:(NSException *)exception
{
    [self validateAndSaveCriticalApplicationData];
    _msg = [NSString stringWithFormat:@"%@%@",[exception reason],[[exception userInfo] objectForKey:UncaughtExceptionHandlerAddressesKey1]];
   NSLog(@"异常信息\n\n%@\n\n",_msg);
#if DEBUG //调试
    UIAlertView *alert =
    [[[UIAlertView alloc]
      initWithTitle:NSLocalizedString(@"抱歉，程序出现了异常", nil)
      message:[NSString stringWithFormat:NSLocalizedString(
                                                           @"如果点击继续，程序有可能会出现其他的问题，建议您还是点击退出按钮并重新打开\n\n"
                                                           @"异常原因如下:\n%@\n%@", nil),
               [exception reason],
               [[exception userInfo] objectForKey:UncaughtExceptionHandlerAddressesKey1]]
      delegate:self
      cancelButtonTitle:NSLocalizedString(@"点次会在xcode现实异常", nil)
      otherButtonTitles:@"不要点击告诉程序员",@"并且截屏保存",nil]
     autorelease];
    
    [alert show];
#else
    
#endif

    
    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    CFArrayRef allModes = CFRunLoopCopyAllModes(runLoop);
    
    while (!dismissed)
    {
        for (NSString *mode in (NSArray *)allModes)
        {
            CFRunLoopRunInMode((CFStringRef)mode, 0.001, false);
        }
    }
    
    CFRelease(allModes);
    
    NSSetUncaughtExceptionHandler(NULL);
    signal(SIGABRT, SIG_DFL);
    signal(SIGILL, SIG_DFL);
    signal(SIGSEGV, SIG_DFL);
    signal(SIGFPE, SIG_DFL);
    signal(SIGBUS, SIG_DFL);
    signal(SIGPIPE, SIG_DFL);
    
    if ([[exception name] isEqual:UncaughtExceptionHandlerSignalExceptionName1])
    {
        kill(getpid(), [[[exception userInfo] objectForKey:UncaughtExceptionHandlerSignalKey1] intValue]);
    }
    else
    {
        [exception raise];
    }
}

@end

void HandleException1(NSException *exception)
{
    int32_t exceptionCount = OSAtomicIncrement32(&UncaughtExceptionCount1);
    if (exceptionCount > UncaughtExceptionMaximum1)
    {
        return;
    }
    
    NSArray *callStack = [UncaughtExceptionHandler1 backtrace];
    NSMutableDictionary *userInfo =
    [NSMutableDictionary dictionaryWithDictionary:[exception userInfo]];
    [userInfo
     setObject:callStack
     forKey:UncaughtExceptionHandlerAddressesKey1];
    
    [[[[UncaughtExceptionHandler1 alloc] init] autorelease]
     performSelectorOnMainThread:@selector(handleException1:)
     withObject:
     [NSException
      exceptionWithName:[exception name]
      reason:[exception reason]
      userInfo:userInfo]
     waitUntilDone:YES];
}

void SignalHandler(int signal)
{
    int32_t exceptionCount = OSAtomicIncrement32(&UncaughtExceptionCount1);
    if (exceptionCount > UncaughtExceptionMaximum1)
    {
        return;
    }
    
    NSMutableDictionary *userInfo =
    [NSMutableDictionary
     dictionaryWithObject:[NSNumber numberWithInt:signal]
     forKey:UncaughtExceptionHandlerSignalKey1];
    
    NSArray *callStack = [UncaughtExceptionHandler1 backtrace];
    [userInfo
     setObject:callStack
     forKey:UncaughtExceptionHandlerAddressesKey1];
    
    [[[[UncaughtExceptionHandler1 alloc] init] autorelease]
     performSelectorOnMainThread:@selector(handleException1:)
     withObject:
     [NSException
      exceptionWithName:UncaughtExceptionHandlerSignalExceptionName1
      reason:
      [NSString stringWithFormat:
       NSLocalizedString(@"Signal %d was raised.", nil),
       signal]
      userInfo:
      [NSDictionary
       dictionaryWithObject:[NSNumber numberWithInt:signal]
       forKey:UncaughtExceptionHandlerSignalKey1]]
     waitUntilDone:YES];
}

void InstallUncaughtExceptionHandler(void)
{
    NSSetUncaughtExceptionHandler(&HandleException1);
    signal(SIGABRT, SignalHandler);
    signal(SIGILL, SignalHandler);
    signal(SIGSEGV, SignalHandler);
    signal(SIGFPE, SignalHandler);
    signal(SIGBUS, SignalHandler);
    signal(SIGPIPE, SignalHandler);
}

